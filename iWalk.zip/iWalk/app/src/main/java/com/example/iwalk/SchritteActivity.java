package com.example.iwalk;

import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.AsyncTaskLoader;

import android.os.AsyncTask;
import android.os.Bundle;

import java.time.DayOfWeek;
import java.time.MonthDay;
import java.util.Calendar;
import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;
import com.anychart.core.cartesian.series.Column;
import com.anychart.enums.Anchor;
import com.anychart.enums.HoverMode;
import com.anychart.enums.Position;
import com.anychart.enums.TooltipPositionMode;
import com.example.iwalk.comm.Comm;
import com.example.iwalk.comm.FakeComm;
import com.example.iwalk.comm.RingSpeicher;
import com.google.type.CalendarPeriod;

import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class SchritteActivity extends AppCompatActivity {

    public class GetDataWorker extends AsyncTask<String, Void, RingSpeicher> {
        @Override
        protected RingSpeicher doInBackground(String... params) {
            final Comm fakeComm = new FakeComm();
            try {
                fakeComm.connect();

            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
            final RingSpeicher speicher = fakeComm.getSchritte();
            fakeComm.disconnect();

            return speicher;
        }

        @Override
        protected void onPostExecute(RingSpeicher result) {


            Calendar calender = Calendar.getInstance();

            AnyChartView anyChartView = findViewById(R.id.textView2);
            calender.add(1,Calendar.DAY_OF_WEEK);
            String.format(calender.toString(), calender.MONDAY);
            Cartesian cartesian = AnyChart.column();


            List<DataEntry> data = new ArrayList<>();
            data.add(new ValueDataEntry("Mo",result.getValue()[1]));
            data.add(new ValueDataEntry("Di", result.getValue()[2]));
            data.add(new ValueDataEntry("Mi",result.getValue()[3]));
            data.add(new ValueDataEntry("Do", result.getValue()[4]));
            data.add(new ValueDataEntry("Fr", result.getValue()[5]));
            data.add(new ValueDataEntry("Sa", result.getValue()[6]));
            data.add(new ValueDataEntry("So", result.getValue()[7]));

            Column column = cartesian.column(data);

            column.tooltip()
                    //.titleFormat("{%X}")
                    .position(Position.CENTER_BOTTOM)
                    .anchor(Anchor.CENTER_BOTTOM)
                    .offsetX(0d)
                    .offsetY(5d)
                    .format("{%Value} Schritte");

            cartesian.animation(true);

            cartesian.yScale().minimum(0d);

            cartesian.tooltip().positionMode(TooltipPositionMode.POINT);
            cartesian.interactivity().hoverMode(HoverMode.BY_X);

            anyChartView.setChart(cartesian);
        }

    }

  @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schritte);

      getSupportActionBar().setDisplayHomeAsUpEnabled(true);
      new GetDataWorker().execute();
    }
}