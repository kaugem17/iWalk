package com.example.iwalk.comm;

public interface Comm
{
  void connect() throws Exception;
  RingSpeicher getSchritte();
  RingSpeicher getStuerze();
  RingSpeicher getBelastungMin();
  RingSpeicher getBelastungMax();
  void disconnect();
}
