package com.example.iwalk.comm;

public class RingSpeicher
{
  private final int[] value;
  private final int lastIndex;

    public RingSpeicher(int[] value, int lastIndex) {
        this.value = value;
        this.lastIndex = lastIndex;
    }

    public int[] getValue() {
        return value;
    }

    public int getLastIndex() {
        return lastIndex;
    }
}
