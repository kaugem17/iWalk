package com.example.iwalk;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.ClipData;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.iwalk.comm.BluetoothTest2;
import com.example.iwalk.comm.Comm;
import com.example.iwalk.comm.FakeComm;
import com.example.iwalk.comm.RingSpeicher;

import java.util.ArrayList;
import java.util.jar.Attributes;

public class HomeScreen extends AppCompatActivity implements Dialog.DialogListener
{
private Toolbar toolbar;
private TextView textViewName;
private TextView textViewnummer;
private Button button;
Button Clicking;

ListView listView;
ArrayList<String> items;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        getSupportActionBar();
       Clicking = (Button) findViewById(R.id.button1);

        Clicking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(HomeScreen.this, SchritteActivity.class);
                startActivity(intent);
            }
        });

        Clicking = (Button) findViewById(R.id.button2);

          Clicking .setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View view)
              {
                  Intent intent = new Intent(HomeScreen.this, StuerzeActivity.class);
                  startActivity(intent);
              }
          });

        Clicking = (Button) findViewById(R.id.button3) ;

          Clicking.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View view)
              {
                  Intent intent = new Intent(HomeScreen.this, BelastungActivity.class);
                  startActivity(intent);
              }
          });



         // listView = (ListView) findViewById(R.id.listview);
          ArrayList<String>  arrayList = new ArrayList<>();
          arrayList.add("Hello");
          button = (Button) findViewById(R.id.dialog_button);
          button.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View view) {
                  openDialog();
              }
          });
        }

    @Override
    public void applyTexts(String name, String nummer) {
            textViewName.setText(name);
            textViewnummer.setText(nummer);

    }

    public void openDialog(){
        Dialog dialog = new Dialog();
        dialog.show(getSupportFragmentManager(),"dialog");

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menubar,menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
                if (id == R.id.bluetoothtest2)
                {
                    Intent intent = new Intent(HomeScreen.this, BluetoothTest2.class);
                    startActivity(intent);
                }
             return super.onOptionsItemSelected(item);
        }
    }


