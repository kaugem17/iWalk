package com.example.iwalk.comm;

public class FakeComm implements Comm
{
    @Override
    public void connect() throws Exception { }

    private RingSpeicher getFakeValues(int maxi)
    {
        try
        {
        Thread.sleep(1000);
        }
        catch (Exception ignore) {}
      final int[] values = new int[60];
      for (int i=0;i<values.length;i++)
        values[i] = (int)Math.round(Math.random()*maxi);
      RingSpeicher ringSpeicher = new RingSpeicher(values, (int)Math.round(Math.random()*60));
      return ringSpeicher;
    }

    @Override
    public RingSpeicher getSchritte()
    {
      return getFakeValues(200);
    }

    @Override
    public RingSpeicher getStuerze() {
      return getFakeValues(3);
    }

    @Override
    public RingSpeicher getBelastungMin()
    {
       return getFakeValues(511);
    }

    @Override
    public RingSpeicher getBelastungMax()
    {
        return getFakeValues(40);
    }

    @Override
    public void disconnect() { }
}
