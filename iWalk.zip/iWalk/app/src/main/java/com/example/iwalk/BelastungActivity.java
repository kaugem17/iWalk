package com.example.iwalk;


import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;
import com.anychart.core.cartesian.series.Line;
import com.anychart.data.Mapping;
import com.anychart.data.Set;
import com.anychart.enums.Anchor;
import com.anychart.enums.MarkerType;
import com.anychart.enums.Position;
import com.anychart.enums.TooltipPositionMode;
import com.anychart.graphics.vector.Stroke;
import com.example.iwalk.comm.Comm;
import com.example.iwalk.comm.FakeComm;
import com.example.iwalk.comm.RingSpeicher;
import java.util.ArrayList;
import java.util.List;

public class BelastungActivity extends AppCompatActivity {

    private class GetDataWorker extends AsyncTask<String, Void, RingSpeicher> {
        @Override
        protected RingSpeicher doInBackground(String... params) {
            final Comm fakeComm = new FakeComm();
            try {
                fakeComm.connect();

            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
            final RingSpeicher speicher = fakeComm.getBelastungMax();
            final RingSpeicher speicher1 = fakeComm.getBelastungMax();
            fakeComm.disconnect();

            return speicher;
        }

        @Override
        protected void onPostExecute(RingSpeicher result) {


            AnyChartView anyChartView = findViewById(R.id.text_view_date3);

            Cartesian cartesian = AnyChart.line();

            cartesian.animation(true);

            cartesian.padding(10d, 20d, 5d, 20d);

            cartesian.crosshair().enabled(true);
            cartesian.crosshair()
                    .yLabel(true)
                    // TODO ystroke
                    .yStroke((Stroke) null, null, null, (String) null, (String) null);

            cartesian.tooltip().positionMode(TooltipPositionMode.POINT);

            cartesian.xAxis(0).labels().padding(5d, 5d, 5d, 5d);

            List<DataEntry> seriesData = new ArrayList<>();
            seriesData.add(new CustomDataEntry("1:00", 0));
            seriesData.add(new CustomDataEntry("2:00", 0));
            seriesData.add(new CustomDataEntry("3:00", 0));
            seriesData.add(new CustomDataEntry("4:00", 0));
            seriesData.add(new CustomDataEntry("5:00", 0));
            seriesData.add(new CustomDataEntry("6:00", 0));
            seriesData.add(new CustomDataEntry("7:00", result.getValue()[2]));
            seriesData.add(new CustomDataEntry("8:00", result.getValue()[3]));
            seriesData.add(new CustomDataEntry("9:00", result.getValue()[4]));
            seriesData.add(new CustomDataEntry("10:00", result.getValue()[5]));
            seriesData.add(new CustomDataEntry("11:00", result.getValue()[6]));
            seriesData.add(new CustomDataEntry("12:00", result.getValue()[7]));
            seriesData.add(new CustomDataEntry("13:00", result.getValue()[8]));
            seriesData.add(new CustomDataEntry("14:00", result.getValue()[9]));
            seriesData.add(new CustomDataEntry("15:00", result.getValue()[10]));
            seriesData.add(new CustomDataEntry("16:00", result.getValue()[11]));
            seriesData.add(new CustomDataEntry("17:00", result.getValue()[12]));
            seriesData.add(new CustomDataEntry("18:00", result.getValue()[13]));
            seriesData.add(new CustomDataEntry("19:00", result.getValue()[14]));
            seriesData.add(new CustomDataEntry("20:00", result.getValue()[15]));
            seriesData.add(new CustomDataEntry("21:00", result.getValue()[16]));
            seriesData.add(new CustomDataEntry("22:00", result.getValue()[17]));
            seriesData.add(new CustomDataEntry("23:00", 0));
            seriesData.add(new CustomDataEntry("24:00", 0));



            Set set = Set.instantiate();
            set.data(seriesData);
            Mapping series1Mapping = set.mapAs("{ x: 'x', value: 'value' }");



            Line series1 = cartesian.line(series1Mapping);
            series1.name("Belastung");
            series1.hovered().markers().enabled(true);
            series1.hovered().markers()
                    .type(MarkerType.LINE)
                    .size(4d);
            series1.tooltip()
                    .position("right")
                    .anchor(Anchor.LEFT_CENTER)
                    .offsetX(5d)
                    .offsetY(5d)
                    .format("{%Value} kg");


            cartesian.legend().enabled(true);
            cartesian.legend().fontSize(13d);
            cartesian.legend().padding(0d, 0d, 10d, 0d);

            anyChartView.setChart(cartesian);
        }

        private class CustomDataEntry extends ValueDataEntry {

            CustomDataEntry(String x, Number value) {
                super(x, value);


            }

        }
    }

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_belastung);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        new BelastungActivity.GetDataWorker().execute();
    }
    }







