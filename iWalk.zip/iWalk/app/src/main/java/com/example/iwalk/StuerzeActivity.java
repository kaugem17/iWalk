package com.example.iwalk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;
import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.anychart.charts.Cartesian;
import com.anychart.charts.Radar;
import com.anychart.core.cartesian.series.Column;
import com.anychart.core.radar.series.Line;
import com.anychart.data.Mapping;
import com.anychart.data.Set;
import com.anychart.enums.Align;
import com.anychart.enums.Anchor;
import com.anychart.enums.HoverMode;
import com.anychart.enums.MarkerType;
import com.anychart.enums.Position;
import com.anychart.enums.TooltipPositionMode;
import com.example.iwalk.comm.Comm;
import com.example.iwalk.comm.FakeComm;
import com.example.iwalk.comm.RingSpeicher;


public class StuerzeActivity extends AppCompatActivity {


    private class GetDataWorker extends AsyncTask<String, Void, RingSpeicher> {
        @Override
        protected RingSpeicher doInBackground(String... params) {
            final Comm fakeComm = new FakeComm();
            try {
                fakeComm.connect();

            }
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
            final RingSpeicher speicher = fakeComm.getStuerze();
            fakeComm.disconnect();

            return speicher;
        }

        @Override
        protected void onPostExecute(RingSpeicher result) {


            Calendar calender = Calendar.getInstance();

            AnyChartView anyChartView = findViewById(R.id.text_view_date2);
            calender.add(1,Calendar.DAY_OF_WEEK);
            String.format(calender.toString(), calender.MONDAY);
            Cartesian cartesian = AnyChart.column();


            List<DataEntry> data = new ArrayList<>();
            data.add(new ValueDataEntry("Jan", result.getValue()[1]));
            data.add(new ValueDataEntry("Feb", result.getValue()[2]));
            data.add(new ValueDataEntry("Mar", result.getValue()[3]));
            data.add(new ValueDataEntry("Apr", result.getValue()[4]));
            data.add(new ValueDataEntry("May", result.getValue()[5]));
            data.add(new ValueDataEntry("Jun", result.getValue()[6]));
            data.add(new ValueDataEntry("Jul", result.getValue()[7]));
            data.add(new ValueDataEntry("Aug", result.getValue()[8]));
            data.add(new ValueDataEntry("Sep", result.getValue()[9]));
            data.add(new ValueDataEntry("Okt", result.getValue()[10]));
            data.add(new ValueDataEntry("Nov", result.getValue()[11]));
            data.add(new ValueDataEntry("Dec", result.getValue()[12]));

            Column column = cartesian.column(data);

            column.tooltip()
                    //.titleFormat("{%X}")
                    .position(Position.CENTER_BOTTOM)
                    .anchor(Anchor.CENTER_BOTTOM)
                    .offsetX(0d)
                    .offsetY(5d)
                    .format("{%Value} Stuerze");

            cartesian.animation(true);

            cartesian.yScale().minimum(0d);

            cartesian.tooltip().positionMode(TooltipPositionMode.POINT);
            cartesian.interactivity().hoverMode(HoverMode.BY_X);

            anyChartView.setChart(cartesian);
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stuerze);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        new StuerzeActivity.GetDataWorker().execute();
    }
}