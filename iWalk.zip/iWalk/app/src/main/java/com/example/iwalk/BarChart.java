/* package com.example.iwalk;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.Paint;
import androidx.compose.ui.graphics.PaintingStyle;
import androidx.compose.ui.graphics.drawscope.Fill;

import java.util.List;

public class BarChart extends View {
    Paint barPainter, axisPainter, guidePainter;
    int barColor, axisColor, guideColor;
    float axisThickness, guideThickness, padding;
    List<Float> series;
    public BarChart(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        axisThickness = 5f;
        guideThickness = 3f;
        padding = 20f;

        barPainter = new Paint();
        barPainter.setStyle(PaintingStyle.Fill);
        barPainter.setColor(Color.LT());


    }
}*/
